import { add } from "./mathUtil.js";
console.log("2 + 3 = ", add(2,3));

import { circleArea, circleCircumference } from
"./mathUtil.js";
const r = 5;
console.log("반지름:", r);
console.log("원의 넓이:", circleArea(r));
console.log("원의 둘레:", circleCircumference(r));