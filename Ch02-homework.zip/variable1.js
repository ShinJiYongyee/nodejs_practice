let age = 20;
const country = "Korea";

console.log("나이 : " , age);
console.log("국가:", country);

age = 21;
console.log("변경된 나이:", age);

// country = "USA"; //const변수는 재할당 불가